#include "stm32f4xx.h"
#include "main.h"

#define GPIOAEN		    (1U<<0)
#define ADC1EN			(1U<<8)
#define ADC_CH1			(1U<<0)
#define ADC_SEQ_LEN_1	 (0x00)
#define CR2_ADON		(1U<<0)
#define CR2_SWSTART		(1U<<30)
#define SR_EOC			(1U<<1)

uint32_t sensor_value;

void pa1_adc_init(void)
{
	/**Configure the ADC GPIO pin **/


	RCC->AHB1ENR |= GPIOAEN;		//Enable clock access to GPIOA/

	GPIOA->MODER |= (1U<<2); 		//Set the mode of PA1 to analog/
	GPIOA->MODER |= (1U<<3);

	/**Configure the ADC module**/


	RCC->APB2ENR |= ADC1EN;			/*Enable clock access to ADC */

	//Conversion sequence start/

	ADC1->SQR3 = ADC_CH1;			//Conversion sequence start/

	ADC1->SQR1 = ADC_SEQ_LEN_1;		//Conversion sequence length/

	ADC1->CR2 |= CR2_ADON; 			//Enable ADC module/

}


void start_conversion(void)
{
	ADC1->CR2 |= (1<<1);

	ADC1->CR2 |= CR2_SWSTART;			//Start adc conversion/

}



uint32_t adc_read(void)
{
	//Wait for conversion to be complete/
	while(!(ADC1->SR & SR_EOC)){}

	//Read converted result/
	return (ADC1->DR);
}
int main(void)
{
	pa1_adc_init();
	start_conversion();
	while(1)
	{

		sensor_value=adc_read();

	}

}
