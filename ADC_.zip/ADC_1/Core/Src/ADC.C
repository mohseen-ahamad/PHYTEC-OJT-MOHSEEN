#include"stm32f4xx.h"
void pa1_adc_init(void);
void start_conversation(void);
