#include "main.h"
void USART6_init(void);
void USART6_write(int c);
void delayMs(int);
char USART6_read(void);

int main (void)
{
	char c;
	USART6_init();
	while (1)
	{
		c = USART6_read();
		USART6_write(c);
	}
}
/* initialize UART6 to transmit at 9600 Baud */

void USART6_init(void)
{
	RCC->AHB1ENR |= 1; 			/* Enable GPIOA clock */
	RCC->APB2ENR |= 0x0020; 	/* Enable UART6 clock */
	/* Configure PA11, PA12 for UART6 TX, RX */
	GPIOA->MODER &= ~0x003C0000;
	GPIOA->MODER |= 0x000CB000; 	/* enable alternate function for PA11, PA12 */
	GPIOA->AFR[1] &= ~0x0FF0;
	GPIOA->AFR[1] |= 0x0880;	/* alt7 for UART6 */
	USART6->BRR = 0x0683; 		/* 9600 baud @ 16 MHz */
	USART6->CR1 = 0x000C; 		/* enable Tx, Rx, 8-bit data */
	USART6->CR2 = 0x0000; 		/* 1 stop bit*/
	USART6->CR3 = 0x0000; 		/* no flow control */
	USART6->CR1 |= 0x2000; 		/*enable UART1 */
}
/* Write a character to UART1 */
void USART6_write (int ch)
{
while (!(USART6->SR & 0x0080)) {}  // wait until Tx buffer empty
USART6->DR = (ch & 0xFF);
}
/* Read a character from UART1 */
char USART6_read(void)
{
while (!(USART6->SR & 0x0020)) {} // wait until char arrives
return USART6->DR;
}
