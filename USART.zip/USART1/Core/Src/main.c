#include "main.h"
void USART1_init(void);
void USART1_write(int c);
void delayMs(int);
char USART1_read(void);

int main (void)
{
	char c;
	USART1_init();
	while (1)
	{
		c = USART1_read();
		USART1_write(c);
	}
}
/* initialize UART1 to transmit at 9600 Baud */

void USART1_init(void)
{
	RCC->AHB1ENR |= 1; 			/* Enable GPIOA clock */
	RCC->APB2ENR |= 0x00010; 	/* Enable UART1 clock */
	/* Configure PA9, PA10 for UART1 TX, RX */
	GPIOA->MODER &= ~0x003C0000;
	GPIOA->MODER |= 0x00280000; 	/* enable alternate function for PA9, PA10 */
	GPIOA->AFR[1] &= ~0x0FF0;
	GPIOA->AFR[1] |= 0x0770;	/* alt7 for UART1 */
	USART1->BRR = 0x0683; 		/* 9600 baud @ 16 MHz */
	USART1->CR1 = 0x000C; 		/* enable Tx, Rx, 8-bit data */
	USART1->CR2 = 0x0000; 		/* 1 stop bit*/
	USART1->CR3 = 0x0000; 		/* no flow control */
	USART1->CR1 |= 0x2000; 		/*enable UART1 */
}
/* Write a character to UART1 */
void USART1_write (int ch)
{
while (!(USART1->SR & 0x0080)) {}  // wait until Tx buffer empty
USART1->DR = (ch & 0xFF);
}
/* Read a character from UART1 */
char USART1_read(void)
{
while (!(USART1->SR & 0x0020)) {} // wait until char arrives
return USART1->DR;
}
