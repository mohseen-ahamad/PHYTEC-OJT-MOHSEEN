
#ifndef SRC_LED_H_
#define SRC_LED_H_
#include "stm32f4xx.h"
void led_init(void);
void led_toggle (void);
#endif /* SRC_LED_H_ */
