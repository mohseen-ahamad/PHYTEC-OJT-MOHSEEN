

#include<led.h>

void led_init(void)
{
RCC->AHB1ENR |= 1;
GPIOA->MODER &= ~0x00000C00;
GPIOA->MODER |= 0x00000400;

}
void led_toggle (void)
{
	GPIOA->ODR |= 0x00000020;
}
